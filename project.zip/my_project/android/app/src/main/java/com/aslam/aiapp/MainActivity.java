package com.aslam.aiapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
