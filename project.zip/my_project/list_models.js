import 'dotenv/config';
import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function getModels() {
  try {
    console.log("उपलब्ध मॉडल्स की लिस्ट निकाली जा रही है...");
    const response = await ai.models.list();
    
    // पूरे रिस्पॉन्स को चेक करने के लिए डायरेक्ट लॉग कर रहे हैं
    console.log("\n📋 गूगल से मिला असली डेटा:");
    console.log(JSON.stringify(response, null, 2));
  } catch (error) {
    console.error("लिस्ट निकालने में एरer आया:", error);
  }
}

getModels();
