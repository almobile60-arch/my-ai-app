import express from 'express';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000; 

app.use(express.json());
// Yeh line aapke frontend HTML folder ko connect karegi
app.use(express.static(path.join(__dirname, 'public')));

const ai = new GoogleGenAI({ apiKey: "AQ.Ab8RN6JBdOD69tYH5HBJR1AgwhVCh6dVsC6kIBV4NZaG4HpnYw" }); 

app.post('/api/ask', async (req, res) => {
  try {
    const { question } = req.body; 
    if (!question) return res.status(400).json({ error: "कृपया सवाल भेजें!" });

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: question,
    });

    res.json({ answer: response.text });
  } catch (error) {
    res.status(500).json({ error: "Kuch gadbad ho gayi!", details: error.message });
  }
});

app.listen(port, () => {
  console.log(`🚀 आपका AI सर्वर http://localhost:${port} पर लाइव है!`);
});
